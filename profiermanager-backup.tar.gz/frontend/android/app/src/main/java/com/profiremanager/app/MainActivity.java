package com.profiremanager.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
